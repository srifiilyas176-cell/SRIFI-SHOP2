SRIFI SHOP FINAL - Ready for Vercel

Run locally:
1. npm install
2. npm run dev

Deploy:
- Push to GitHub and import to Vercel or use Vercel Git integration.
